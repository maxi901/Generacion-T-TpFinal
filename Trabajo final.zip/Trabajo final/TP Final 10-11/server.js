const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const PORT = 3000;

// Conexión con la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'nueva_timesheetdb'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Middleware para manejar datos del formulario
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para servir la página de inicio de sesión (index)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// También puedes agregar una ruta para servir el archivo index.html directamente
app.get('/index.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html')); // Esto también funcionará si accedes a /index.html
});

// Sirve archivos estáticos desde la carpeta actual
app.use(express.static(__dirname));

// Ruta para servir la página de timesheet
app.get('/timesheet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'timesheet.html'));
});

// Ruta para servir la página de administración
app.get('/admin.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Ruta para manejar el inicio de sesión
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM usuarios WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error en la consulta:', err);
            return res.status(500).send('Error en el servidor.');
        } else if (results.length > 0) {
            const user = results[0];
            res.status(200).json({ esAdmin: user.esAdmin }); // Enviar rol de usuario
        } else {
            res.status(401).send('Usuario o contraseña incorrectos.'); // Error de autenticación
        }
    });
});

// Ruta para enviar los datos del timesheet
app.post('/submit-timesheet', (req, res) => {
    console.log('Datos recibidos:', req.body);
    const { fecha, horas } = req.body;
    const usuario = req.body.nombreApellido || localStorage.getItem('username');

    console.log('Preparando para insertar:', usuario, fecha, horas);

    // Verifica que los datos estén completos antes de hacer la consulta
    if (!usuario || !fecha || !horas) {
        return res.status(400).send('Faltan datos requeridos.');
    }

    // Consulta para obtener el idSector del usuario
    const queryUserSector = 'SELECT idSector FROM usuarios WHERE username = ?';
    db.query(queryUserSector, [usuario], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error al obtener idSector del usuario:', err);
            return res.status(500).send('Error al obtener el sector del usuario.');
        }

        const idSector = results[0].idSector; // Obtener el idSector del usuario

        // Inserción en la tabla timesheet con idSector
        const query = 'INSERT INTO timesheet (usuario, fecha, horas, id_sector) VALUES (?, ?, ?, ?)';
        db.query(query, [usuario, fecha, horas, idSector], (err) => {
            if (err) {
                console.error('Error al insertar en la base de datos:', err);
                return res.status(500).send('Error al agregar la entrada.');
            }
            
            res.send('Horas registradas correctamente.');
        });
    });
});

// Ruta para obtener usuarios desde la tabla usuarios
app.get('/get-users', (req, res) => {
    const query = 'SELECT DISTINCT username FROM usuarios'; // Ajuste en la consulta SQL
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios.');
        }
        res.json(results);
    });
});

// Ruta para obtener sectores
app.get('/get-sectors', (req, res) => {
    const query = 'SELECT nombre FROM sectores'; // Asegúrate de que "sectores" y "nombre" existan en tu base de datos
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener sectores:', err);
            return res.status(500).send('Error al obtener sectores.');
        }
        res.json(results);
    });
});

app.post('/update-idsector', (req, res) => {
    const { username, sectorName } = req.body;

    console.log('Datos recibidos para actualizar idSector:', { username, sectorName }); // Ver datos recibidos

    // Consulta para obtener el idSector a partir del nombre del sector
    const querySectorId = 'SELECT id FROM sectores WHERE nombre = ?';
    db.query(querySectorId, [sectorName], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error al obtener idSector:', err);
            return res.status(500).send('Error al obtener idSector.');
        }

        const idSector = results[0].id; // Obtener el id del sector

        // Actualizar el idSector en la tabla usuarios
        const updateQuery = 'UPDATE usuarios SET idSector = ? WHERE username = ?';
        db.query(updateQuery, [idSector, username], (err) => {
            if (err) {
                console.error('Error al actualizar el idSector:', err);
                return res.status(500).send('Error al actualizar el idSector.');
            }
            res.send('idSector actualizado correctamente.');
        });
    });
});

// Ruta para obtener los datos del timesheet de un usuario específico
app.get('/user-data', (req, res) => {
    const usuario = req.query.usuario; // Obtener el nombre de usuario desde los parámetros de la URL

    if (!usuario) {
        return res.status(400).send('Se requiere el nombre de usuario.');
    }

    const query = `
        SELECT timesheet.usuario, sectores.nombre AS sector, timesheet.fecha, timesheet.horas
        FROM timesheet
        INNER JOIN sectores ON timesheet.id_sector = sectores.id
        WHERE timesheet.usuario = ?
    `;

    db.query(query, [usuario], (err, results) => {
        if (err) {
            console.error('Error al obtener datos del timesheet:', err);
            return res.status(500).send('Error al obtener datos del timesheet.');
        }

        console.log(results); // Verificar resultados en la consola
        res.json(results); // Enviar los datos filtrados al cliente
    });
});

// Ruta para obtener datos del timesheet para la administración
app.get('/admin-data', (req, res) => {
    const query = `
        SELECT timesheet.usuario, sectores.nombre AS sector, timesheet.fecha, timesheet.horas
        FROM timesheet
        INNER JOIN sectores ON timesheet.id_sector = sectores.id
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener datos del timesheet:', err);
            return res.status(500).send('Error al obtener datos del timesheet.');
        }
        
        console.log(results); // Verificar resultados en la consola
        res.json(results);
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log('Servidor escuchando en el puerto', PORT);
});

// Ruta para agregar un nuevo usuario
app.post('/crear-usuario', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).send('Faltan datos requeridos.');
    }

    const query = 'INSERT INTO usuarios (username, password, esAdmin) VALUES (?, ?, 0)';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error al agregar usuario:', err);
            return res.status(500).send('Error al agregar usuario.');
        }
        res.send('Usuario agregado correctamente.');
    });
});

// Ruta para actualizar un sector
app.put('/update-sector', (req, res) => {
    const { nombreAnterior, nuevoNombre } = req.body;

    if (!nombreAnterior || !nuevoNombre) {
        return res.status(400).send('Se requieren ambos nombres.');
    }

    const query = 'UPDATE sectores SET nombre = ? WHERE nombre = ?';
    db.query(query, [nuevoNombre, nombreAnterior], (err, result) => {
        if (err) {
            console.error('Error al actualizar el sector:', err);
            return res.status(500).send('Error al actualizar el sector.');
        }

        if (result.affectedRows > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false, message: 'No se encontró el sector.' });
        }
    });
});

// Ruta para eliminar un sector
app.delete('/delete-sector', (req, res) => {
    const { nombre } = req.body;

    if (!nombre) {
        return res.status(400).send('Se requiere el nombre del sector.');
    }

    const query = 'DELETE FROM sectores WHERE nombre = ?';
    db.query(query, [nombre], (err, result) => {
        if (err) {
            console.error('Error al eliminar el sector:', err);
            return res.status(500).send('Error al eliminar el sector.');
        }

        if (result.affectedRows > 0) {
            res.json({ success: true });
        } else {
            res.json({ success: false, message: 'No se encontró el sector.' });
        }
    });
});

// Ruta para agregar un nuevo sector
app.post('/add-sector', (req, res) => {
    const { nombre } = req.body;

    if (!nombre || nombre.trim() === '') {
        return res.status(400).json({ success: false, message: 'El nombre del sector es requerido.' });
    }

    // Verificar si el sector ya existe
    const query = 'SELECT * FROM sectores WHERE nombre = ?';
    db.execute(query, [nombre], (err, results) => {
        if (err) {
            console.error('Error al verificar el sector:', err);
            return res.status(500).json({ success: false, message: 'Hubo un error al verificar el sector.' });
        }

        if (results.length > 0) {
            return res.status(400).json({ success: false, message: 'El sector ya existe.' });
        }

        // Insertar el nuevo sector
        const insertQuery = 'INSERT INTO sectores (nombre) VALUES (?)';
        db.execute(insertQuery, [nombre], (err, result) => {
            if (err) {
                console.error('Error al agregar el sector:', err);
                return res.status(500).json({ success: false, message: 'Hubo un error al agregar el sector.' });
            }

            return res.status(200).json({ success: true, message: 'Sector agregado con éxito.' });
        });
    });
});

app.get('/get-users-pant', (req, res) => {
    // Consulta SQL para obtener todos los usuarios y la suma de las horas trabajadas, si existen
    const query = `
        SELECT u.username AS usuario, IFNULL(SUM(t.horas), 0) AS total_horas
        FROM usuarios u
        LEFT JOIN timesheet t ON u.username = t.usuario
        GROUP BY u.username
    `;

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener los usuarios y horas:', err);
            return res.status(500).json({ error: 'Hubo un problema al obtener los usuarios y horas.' });
        }
        res.json(results);  // Devuelve los resultados como JSON
    });
});


// Ruta para actualizar un usuario
app.put('/update-user', (req, res) => {
    const { usuarioAnterior, nuevoNombre } = req.body;

    // Actualizar el nombre del usuario en la tabla 'usuarios'
    const queryUsuarios = 'UPDATE usuarios SET username = ? WHERE username = ?';

    // Actualizar el nombre del usuario en la tabla 'timesheet'
    const queryTimesheet = 'UPDATE timesheet SET usuario = ? WHERE usuario = ?';

    db.beginTransaction((err) => {
        if (err) {
            console.error('Error al iniciar la transacción:', err);
            return res.status(500).json({ success: false, error: 'Hubo un problema al iniciar la transacción.' });
        }

        // Ejecutar la consulta para la tabla 'usuarios'
        db.query(queryUsuarios, [nuevoNombre, usuarioAnterior], (err, result) => {
            if (err) {
                return db.rollback(() => {
                    console.error('Error al actualizar el usuario en usuarios:', err);
                    return res.status(500).json({ success: false, error: 'Hubo un problema al actualizar el usuario en usuarios.' });
                });
            }

            // Ejecutar la consulta para la tabla 'timesheet'
            db.query(queryTimesheet, [nuevoNombre, usuarioAnterior], (err, result) => {
                if (err) {
                    return db.rollback(() => {
                        console.error('Error al actualizar el usuario en timesheet:', err);
                        return res.status(500).json({ success: false, error: 'Hubo un problema al actualizar el usuario en timesheet.' });
                    });
                }

                // Confirmar la transacción si ambas actualizaciones fueron exitosas
                db.commit((err) => {
                    if (err) {
                        return db.rollback(() => {
                            console.error('Error al confirmar la transacción:', err);
                            return res.status(500).json({ success: false, error: 'Hubo un problema al confirmar la transacción.' });
                        });
                    }
                    res.json({ success: true });
                });
            });
        });
    });
});

// Ruta para eliminar un usuario
app.delete('/delete-user', (req, res) => {
    const { usuario } = req.body;

    // Eliminar el usuario de la tabla 'usuarios'
    const queryUsuarios = 'DELETE FROM usuarios WHERE username = ?';

    // Eliminar el usuario de la tabla 'timesheet'
    const queryTimesheet = 'DELETE FROM timesheet WHERE usuario = ?';

    db.beginTransaction((err) => {
        if (err) {
            console.error('Error al iniciar la transacción:', err);
            return res.status(500).json({ success: false, error: 'Hubo un problema al iniciar la transacción.' });
        }

        // Ejecutar la consulta para la tabla 'usuarios'
        db.query(queryUsuarios, [usuario], (err, result) => {
            if (err) {
                return db.rollback(() => {
                    console.error('Error al eliminar el usuario de usuarios:', err);
                    return res.status(500).json({ success: false, error: 'Hubo un problema al eliminar el usuario de usuarios.' });
                });
            }

            // Ejecutar la consulta para la tabla 'timesheet'
            db.query(queryTimesheet, [usuario], (err, result) => {
                if (err) {
                    return db.rollback(() => {
                        console.error('Error al eliminar el usuario de timesheet:', err);
                        return res.status(500).json({ success: false, error: 'Hubo un problema al eliminar el usuario de timesheet.' });
                    });
                }

                // Confirmar la transacción si ambas eliminaciones fueron exitosas
                db.commit((err) => {
                    if (err) {
                        return db.rollback(() => {
                            console.error('Error al confirmar la transacción:', err);
                            return res.status(500).json({ success: false, error: 'Hubo un problema al confirmar la transacción.' });
                        });
                    }
                    res.json({ success: true });
                });
            });
        });
    });
});
