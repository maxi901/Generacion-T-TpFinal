// Login
function login(event) {
    event.preventDefault(); // Prevenir el comportamiento predeterminado de recargar la página

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => {
        if (response.ok) {
            localStorage.setItem('username', username); // Guardar el usuario en localStorage
            window.location.href = '/timesheet.html'; // Redirigir al timesheet
        } else {
            return response.text().then(text => {
                alert(text); // Mostrar mensaje de error
            });
        }
    })
    .catch(error => console.error('Error:', error));
}

// Agregar entrada de timesheet
function agregarEntrada() {
    const fecha = document.getElementById('fecha').value;
    const horas = document.getElementById('horas').value;
    const usuario = localStorage.getItem('username'); // Obtener el nombre de usuario de localStorage

    if (fecha && horas && usuario) {
        fetch('/submit-timesheet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombreApellido: usuario, fecha, horas })
        })
        .then(response => {
            if (response.ok) {
                alert("Entrada agregada con éxito."); // Mensaje de éxito
                cargarDatosTimesheet(); // Actualizar tabla
                document.getElementById('fecha').value = new Date().toISOString().split('T')[0]; // Establecer la fecha a hoy
                document.getElementById('horas').value = ''; // Limpiar campo de horas
            } else {
                throw new Error("Error al agregar la entrada");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema al agregar la entrada.');
        });
    } else {
        alert('Por favor, complete todos los campos.');
    }
}

// Cargar datos del timesheet en la tabla
function cargarDatosTimesheet() {
    fetch('/timesheet-data')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('timesheetTable').getElementsByTagName('tbody')[0];
            tableBody.innerHTML = ''; // Limpiar la tabla

            data.forEach(row => {
                const newRow = tableBody.insertRow();
                newRow.insertCell(0).textContent = row.username; // Usuario
                newRow.insertCell(1).textContent = row.sector;  // Sector

                // Formatear la fecha antes de mostrarla
                const fechaFormateada = new Date(row.fecha).toLocaleDateString('es-ES');
                newRow.insertCell(2).textContent = fechaFormateada; // Fecha formateada

                newRow.insertCell(3).textContent = row.horas; // Horas trabajadas
            });
        })
        .catch(error => {
            console.error('Error al cargar datos:', error);
            alert('Hubo un problema al cargar los datos del timesheet.');
        });
}

// Establecer la fecha actual en el input de fecha
document.addEventListener('DOMContentLoaded', () => {
    const hoy = new Date().toISOString().split('T')[0];
    document.getElementById('fecha').value = hoy;

    // Cargar los datos del timesheet al iniciar la página si es la página correcta
    if (window.location.pathname === '/timesheet.html') {
        cargarDatosTimesheet();
    }
});
