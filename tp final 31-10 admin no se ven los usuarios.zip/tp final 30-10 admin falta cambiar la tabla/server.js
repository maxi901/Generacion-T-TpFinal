const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const PORT = 3000;

// Conexión con la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'nueva_timesheetdb'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Middleware para manejar datos del formulario
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para servir la página de inicio de sesión (index)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Ruta para servir la página de timesheet
app.get('/timesheet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'timesheet.html'));
});

// Ruta para servir la página de administración
app.get('/admin.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Ruta para manejar el inicio de sesión
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Usuario:', username, 'Contraseña:', password);

    const query = 'SELECT * FROM usuarios WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error en la consulta:', err);
            return res.status(500).send('Error en el servidor.');
        } else if (results.length > 0) {
            const user = results[0]; // Obtener el primer resultado
            console.log('Usuario encontrado:', user);
            console.log('esAdmin:', user.esAdmin);
            if (user.esAdmin === 1) {
                res.redirect('/admin.html'); // Redirigir a admin.html si es admin
            } else {
                res.redirect('/timesheet.html'); // Redirigir a timesheet.html si no es admin
            }
        } else {
            res.status(401).send('Usuario o contraseña incorrectos.');
        }
    });
});

// Ruta para enviar los datos del timesheet
app.post('/submit-timesheet', (req, res) => {
    console.log('Datos recibidos:', req.body);
    const { fecha, horas } = req.body; // El nombreApellido se obtiene de la sesión o de localStorage
    const usuario = req.body.nombreApellido || localStorage.getItem('username'); // Asegúrate de que se esté enviando correctamente el nombre del usuario

    console.log('Preparando para insertar:', usuario, fecha, horas);

    // Verifica que los datos estén completos antes de hacer la consulta
    if (!usuario || !fecha || !horas) {
        return res.status(400).send('Faltan datos requeridos.');
    }

    const query = 'INSERT INTO timesheet (usuario, fecha, horas) VALUES (?, ?, ?)';
    db.query(query, [usuario, fecha, horas], (err, results) => {
        if (err) {
            console.error('Error al insertar en la base de datos:', err);
            return res.status(500).send('Error al agregar la entrada.');
        }
        
        res.send('Horas registradas correctamente.');
    });
});


// Ruta para obtener usuarios desde la tabla timesheet
app.get('/get-users', (req, res) => {
    const query = 'SELECT DISTINCT username AS name FROM usuarios'; // Asegúrate de que el nombre de la columna sea correcto
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios.');
        }
        res.json(results);
    });
});

// Ruta para obtener sectores
app.get('/get-sectors', (req, res) => {
    const query = 'SELECT nombre FROM sectores'; // Asegúrate de que "sectores" y "nombre" existan en tu base de datos
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener sectores:', err);
            return res.status(500).send('Error al obtener sectores.');
        }
        res.json(results);
    });
});

app.post('/update-idsector', (req, res) => {
    const { username, sectorName } = req.body;

    // Consulta para obtener el idSector a partir del nombre del sector
    const querySectorId = 'SELECT id FROM sectores WHERE nombre = ?';
    db.query(querySectorId, [sectorName], (err, results) => {
        if (err || results.length === 0) {
            console.error('Error al obtener idSector:', err);
            return res.status(500).send('Error al obtener idSector.');
        }

        const idSector = results[0].id; // Obtener el id del sector

        // Actualizar el idSector en la tabla usuarios
        const updateQuery = 'UPDATE usuarios SET idSector = ? WHERE username = ?';
        db.query(updateQuery, [idSector, username], (err) => {
            if (err) {
                console.error('Error al actualizar el idSector:', err);
                return res.status(500).send('Error al actualizar el idSector.');
            }
            res.send('idSector actualizado correctamente.');
        });
    });
});

// Ruta para obtener los datos del timesheet
app.get('/timesheet-data', (req, res) => {
    const query = `
        SELECT u.username, s.nombre AS sector, t.fecha, t.horas
        FROM timesheet t
        JOIN usuarios u ON t.usuario = u.username
        JOIN sectores s ON u.idSector = s.id;
    `;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener los datos del timesheet:', err);
            return res.status(500).send('Error al obtener los datos del timesheet.');
        }
        res.json(results);
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log('Servidor escuchando en el puerto', PORT);
});
