const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const PORT = 3000;

// Conexión con la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'timesheet'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Middleware para manejar datos del formulario
app.use(bodyParser.urlencoded({ extended: true }));

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para servir la página de inicio de sesión (index)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Ruta para servir la página de timesheet
app.get('/timesheet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'timesheet.html'));
});


app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Usuario:', username, 'Contraseña:', password);

    const query = 'SELECT * FROM login WHERE usuario = ? AND contrasena = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            res.status(500).send('Error en el servidor.');
        } else if (results.length > 0) {
            res.redirect('/timesheet.html');
        } else {
            res.status(401).send('Usuario o contraseña incorrectos.');
        }
    });
});

app.post('/submit-timesheet', (req, res) => {
    console.log('Datos recibidos:', req.body); // Verifica que los datos estén llegando
    const { nombreApellido, fecha, proyecto, horas } = req.body;

    console.log('Preparando para insertar:', nombreApellido, fecha, proyecto, horas); // Verificar datos antes de la inserción

    const query = 'INSERT INTO timesheet (nombre_apellido, fecha, proyecto, horas) VALUES (?, ?, ?, ?)';
    db.query(query, [nombreApellido, fecha, proyecto, horas], (err, results) => {
        if (err) {
            console.error('Error al insertar en la base de datos:', err);
            return res.status(500).send('Error al agregar la entrada.');
        }
        
        res.send('Horas registradas correctamente.');
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log('Servidor escuchando en el puerto', PORT);
});
