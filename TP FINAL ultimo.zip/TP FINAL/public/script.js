function login(event) {
    event.preventDefault();  // Prevenir el comportamiento predeterminado de recargar la página

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Realizar la solicitud POST al servidor
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => {
        if (response.ok) {
            // Redirigir a la página de timesheet si el login es exitoso
            window.location.href = '/timesheet.html';
        } else {
            return response.text().then(text => {
                alert(text);  // Mostrar mensaje de error
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}


// Función para agregar entrada al Timesheet
function agregarEntrada() {
    const nombreApellido = document.getElementById('nombreApellido').value;
    const fechaRaw = document.getElementById('fecha').value;
    const proyecto = document.getElementById('proyecto').value;
    const horas = document.getElementById('horas').value;

    if (nombreApellido && fechaRaw && proyecto && horas) {
        const fecha = formatoLatinoamericano(fechaRaw);

        const table = document.getElementById('timesheetTable').getElementsByTagName('tbody')[0];
        const newRow = table.insertRow();

        const nombreApellidoCell = newRow.insertCell(0);
        const fechaCell = newRow.insertCell(1);
        const proyectoCell = newRow.insertCell(2);
        const horasCell = newRow.insertCell(3);

        nombreApellidoCell.tectContent = nombreApellido;
        fechaCell.textContent = fecha;
        proyectoCell.textContent = proyecto;
        horasCell.textContent = horas;

        document.getElementById('nombreApellido').value = '';
        document.getElementById('fecha').value = '';
        document.getElementById('proyecto').value = '';
        document.getElementById('horas').value = '';
    } else {
        alert('Por favor, complete todos los campos.');
    }
}

// Función para convertir la fecha al formato DD/MM/AAAA
function formatoLatinoamericano(fecha) {
    const partes = fecha.split('-');
    const año = partes[0];
    const mes = partes[1];
    const dia = partes[2];
    return `${dia}/${mes}/${año}`;
}

function agregarEntrada() {
    const nombreApellido = document.getElementById('nombreApellido').value;
    const fecha = document.getElementById('fecha').value;
    const proyecto = document.getElementById('proyecto').value;
    const horas = document.getElementById('horas').value;

    if (fecha && proyecto && horas) {
        fetch('/submit-timesheet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nombreApellido: nombreApellido,
                fecha: fecha,
                proyecto: proyecto,
                horas: horas
            })
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            // Limpiar campos del formulario después de enviar
            document.getElementById('nombreApellido').value = '';
            document.getElementById('fecha').value = '';
            document.getElementById('proyecto').value = '';
            document.getElementById('horas').value = '';
        })
        .catch(err => console.error('Error:', err));
    } else {
        alert('Por favor, complete todos los campos.');
    }
}

