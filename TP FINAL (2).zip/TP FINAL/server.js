const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const PORT = 3000;

// Conexión con la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'timesheetbd'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Ruta para servir la página de login
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log(`Usuario: ${username}, Contraseña: ${password}`);  // Verifica que llegan los datos

    const query = 'SELECT * FROM usuarios WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            res.status(500).send('Error en el servidor.');
        } else if (results.length > 0) {
            res.redirect('/timesheet.html');
        } else {
            res.status(401).send('Usuario o contraseña incorrectos.');
        }
    });
});

// Ruta para servir la página de timesheet
app.get('/timesheet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'timesheet.html'));
});

// Ruta para manejar el envío de las horas registradas
app.post('/submit-timesheet', (req, res) => {
    const { date, hours } = req.body;

    // Aquí podrías agregar lógica para guardar el timesheet en la base de datos
    res.send('Horas registradas correctamente.');
});

app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});
