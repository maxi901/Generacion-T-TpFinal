const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const path = require('path');
const app = express();
const PORT = 3000;

// Conexión con la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'admin',
    database: 'timesheetdb'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Middleware para manejar datos del formulario
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para servir la página de inicio de sesión (index)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Ruta para servir la página de timesheet
app.get('/timesheet.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'timesheet.html'));
});

// Ruta para servir la página de administración
app.get('/admin.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

// Ruta para manejar el inicio de sesión
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log('Usuario:', username, 'Contraseña:', password);

    const query = 'SELECT * FROM usuarios WHERE username = ? AND password = ?';
    db.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error en la consulta:', err);
            return res.status(500).send('Error en el servidor.');
        } else if (results.length > 0) {
            const user = results[0]; // Obtener el primer resultado
            console.log('Usuario encontrado:', user);
            console.log('esAdmin:', user.esAdmin);
            if (user.esAdmin === 1) {
                res.redirect('/admin.html'); // Redirigir a admin.html si es admin
            } else {
                res.redirect('/timesheet.html'); // Redirigir a timesheet.html si no es admin
            }
        } else {
            res.status(401).send('Usuario o contraseña incorrectos.');
        }
    });
});

// Ruta para enviar los datos del timesheet
app.post('/submit-timesheet', (req, res) => {
    console.log('Datos recibidos:', req.body);
    const { nombreApellido, fecha, proyecto, horas } = req.body;

    console.log('Preparando para insertar:', nombreApellido, fecha, proyecto, horas);

    const query = 'INSERT INTO timesheet (nombre_apellido, fecha, proyecto, horas) VALUES (?, ?, ?, ?)';
    db.query(query, [nombreApellido, fecha, proyecto, horas], (err, results) => {
        if (err) {
            console.error('Error al insertar en la base de datos:', err);
            return res.status(500).send('Error al agregar la entrada.');
        }
        
        res.send('Horas registradas correctamente.');
    });
});

// Ruta para obtener usuarios desde la tabla timesheet
app.get('/get-users', (req, res) => {
    const query = 'SELECT DISTINCT nombre_apellido AS name FROM timesheet'; // Asegúrate de que el nombre de la columna sea correcto
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener usuarios:', err);
            return res.status(500).send('Error al obtener usuarios.');
        }
        res.json(results);
    });
});

// Ruta para obtener sectores
app.get('/get-sectors', (req, res) => {
    const query = 'SELECT nombre FROM sectores'; // Asegúrate de que "sectores" y "nombre" existan en tu base de datos
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener sectores:', err);
            return res.status(500).send('Error al obtener sectores.');
        }
        res.json(results);
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log('Servidor escuchando en el puerto', PORT);
});
