function login(event) {
    event.preventDefault(); // Prevenir el comportamiento predeterminado de recargar la página

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Realizar la solicitud POST al servidor
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => {
        if (response.ok) {
            // Redirigir a la página de timesheet si el login es exitoso
            window.location.href = '/timesheet.html';
        } else {
            return response.text().then(text => {
                alert(text); // Mostrar mensaje de error
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function agregarEntrada() {
    const nombreApellido = document.getElementById('nombreApellido').value;
    const fecha = document.getElementById('fecha').value;
    const proyecto = document.getElementById('proyecto').value;
    const horas = document.getElementById('horas').value;

    if (nombreApellido && fecha && proyecto && horas) {
        // Obtener el tbody de la tabla
        const tableBody = document.getElementById('timesheetTable').getElementsByTagName('tbody')[0];
        const newRow = tableBody.insertRow();

        // Insertar celdas en el orden correcto
        newRow.insertCell(0).textContent = nombreApellido; // Nombre y Apellido
        newRow.insertCell(1).textContent = fecha; // Fecha ya en formato correcto
        newRow.insertCell(2).textContent = proyecto; // Proyecto/Tarea
        newRow.insertCell(3).textContent = horas; // Horas trabajadas

        fetch('/submit-timesheet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nombreApellido: nombreApellido,
                fecha: fecha, // Usamos la fecha directamente
                proyecto: proyecto,
                horas: horas
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al agregar la entrada');
            }
            return response.text();
        })
        .then(data => {
            alert(data); // Mensaje de éxito
            // Limpiar campos del formulario
            document.getElementById('nombreApellido').value = '';
            document.getElementById('fecha').value = '';
            document.getElementById('proyecto').value = '';
            document.getElementById('horas').value = '';
        })
        .catch(err => {
            console.error('Error:', err);
            alert('Hubo un problema al agregar la entrada.');
        });
        
    } else {
        alert('Por favor, complete todos los campos.');
    }
}
