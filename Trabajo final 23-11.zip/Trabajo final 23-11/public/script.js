// Agregar entrada de timesheet
function agregarEntrada() {
    const fecha = document.getElementById('fecha').value;
    const horas = document.getElementById('horas').value;
    const usuario = localStorage.getItem('username'); // Obtener el nombre de usuario de localStorage

    if (fecha && horas && usuario) {
        fetch('/submit-timesheet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nombreApellido: usuario, fecha, horas })
        })
        .then(response => {
            if (response.ok) {
                alert("Entrada agregada con éxito."); // Mensaje de éxito
                cargarDatosTimesheetUsuario(); // Actualizar tabla
                document.getElementById('fecha').value = new Date().toISOString().split('T')[0]; // Establecer la fecha a hoy
                document.getElementById('horas').value = ''; // Limpiar campo de horas
            } else {
                throw new Error("Error al agregar la entrada");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un problema al agregar la entrada.');
        });
    } else {
        alert('Por favor, complete todos los campos.');
    }
}

// Función para confirmar la entrada y actualizar el idSector
function confirmarEntrada() {
    const username = document.getElementById('usuario').value;
    const sectorName = document.getElementById('sector').value;

    if (username && sectorName) {
        fetch('/update-idsector', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, sectorName }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar el idSector: ' + response.statusText);
            }
            return response.text();
        })
        .then(message => {
            alert(message); // Muestra un mensaje al usuario
            loadAdminData(); // Recargar datos de administración
            // Limpiar los campos después de la actualización
            document.getElementById('usuario').value = '';
            document.getElementById('sector').value = '';
            verificarCampos(); // Actualizar la visibilidad del botón
        })
        .catch(error => console.error('Error:', error));
    } else {
        alert('Por favor, complete todos los campos.');
    }
}

// Establecer la fecha actual en el input de fecha
document.addEventListener('DOMContentLoaded', () => {
    const hoy = new Date().toISOString().split('T')[0];
    document.getElementById('fecha').value = hoy;

    // Cargar los datos del timesheet al iniciar la página si es la página correcta
    if (window.location.pathname === '/timesheet.html') {
        cargarDatosTimesheet();
    }
});

// Llamar a cargarDatosAdmin al cargar la página de administración
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname === '/admin.html') {
        cargarDatosAdmin();
    }
});
