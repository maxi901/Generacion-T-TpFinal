function login(event) {
    event.preventDefault(); // Prevenir el comportamiento predeterminado de recargar la página

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Realizar la solicitud POST al servidor
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            username: username,
            password: password
        })
    })
    .then(response => {
        if (response.ok) {
            // Redirigir a la página de timesheet si el login es exitoso
            window.location.href = '/timesheet.html';
        } else {
            return response.text().then(text => {
                alert(text); // Mostrar mensaje de error
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function agregarEntrada() {
    const fecha = document.getElementById('fecha').value;
    const horas = document.getElementById('horas').value;
    const usuario = localStorage.getItem('username'); // Obtener el nombre de usuario de localStorage

    if (fecha && horas && usuario) {
        fetch('/submit-timesheet', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                nombreApellido: usuario, // Asegúrate de que esto se envíe
                fecha: fecha,
                horas: horas
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al agregar la entrada');
            }
            return response.text();
        })
        .then(data => {
            alert(data); // Mensaje de éxito
            // Limpiar campos del formulario
            document.getElementById('fecha').value = '';
            document.getElementById('horas').value = '';
            
            // Establecer el valor del campo de fecha a hoy
            const hoy = new Date().toISOString().split('T')[0]; // Obtener la fecha actual en formato YYYY-MM-DD
            document.getElementById('fecha').value = hoy; // Establecer el valor

            // Llamar a la función para recargar los datos de la tabla
            cargarDatosTimesheet(); // Actualiza la tabla
        })
        .catch(err => {
            console.error('Error:', err);
            alert('Hubo un problema al agregar la entrada.');
        });
    } else {
        alert('Por favor, complete todos los campos.'); // Este mensaje se mostrará si hay campos vacíos
    }
}




// Función para cargar los datos del timesheet
function cargarDatosTimesheet() {
    fetch('/timesheet-data')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('timesheetTable').getElementsByTagName('tbody')[0];
            tableBody.innerHTML = ''; // Limpiar la tabla antes de agregar nuevos datos
            data.forEach(row => {
                const newRow = tableBody.insertRow();
                newRow.insertCell(0).textContent = row.username; // Usuario
                newRow.insertCell(1).textContent = row.sector;  // Sector
                // Formatear la fecha antes de mostrarla
                const fechaObj = new Date(row.fecha);
                const fechaFormateada = fechaObj.toLocaleDateString('es-ES');
                newRow.insertCell(2).textContent = fechaFormateada;   // Fecha formateada
                newRow.insertCell(3).textContent = row.horas;   // Horas trabajadas
            });
        })
        .catch(err => {
            console.error('Error al cargar datos:', err);
            alert('Hubo un problema al cargar los datos del timesheet.');
        });
}


// Obtener la fecha actual en formato YYYY-MM-DD
const hoy = new Date().toISOString().split('T')[0];
// Establecer el valor inicial del input como la fecha de hoy
document.getElementById('fecha').value = hoy;

// Cargar los datos del timesheet al iniciar la página
document.addEventListener('DOMContentLoaded', () => {
    if (window.location.pathname === '/timesheet.html') {
        cargarDatosTimesheet(); // Llamar a la función para cargar datos
    }
});
